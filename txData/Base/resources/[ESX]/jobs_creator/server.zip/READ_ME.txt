Installation: https://jaksam1074.gitbook.io/jaksams-scripts-documentation/jobs-creator/installation

Replace default notifications: https://jaksam1074.gitbook.io/jaksams-scripts-documentation/jobs-creator/client/notifications/replace-default-notifications

Replace default progress bar: https://jaksam1074.gitbook.io/jaksams-scripts-documentation/jobs-creator/client/replace-disable-default-progress-bar

Replace default stash/inventory: https://jaksam1074.gitbook.io/jaksams-scripts-documentation/jobs-creator/client/replace-default-stash

Support Discord: https://discord.gg/7prxECaP6J

If for any reason the script doesn't start, there will be an error explaining you what's the cause of it.
Here you can find all solutions to the errors related to the escrow system, that will solve the explained errors https://jaksam1074.gitbook.io/jaksams-scripts-documentation/fivem-escrow-system-errors/home